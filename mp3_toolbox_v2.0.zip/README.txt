Mp3 toolbox for Matlab.
M.Sc. Alfredo Fernandez Franco
Aalborg University
Departament of Acoustics
aberserk@yahoo.com

Includes 2 functions to write and read MP3 files. It works like the commands
WAVWRITE and WAVREAD.
1.- Just unpack in the toolbox folder under the MATLAB directory.
2.- Set the MATLAB search path to include that folder.

This version was made in MATLAB for WINDOWS only.

Several bugs fixed and improved functionality. If you find any bug let me know.

01-11-2004.